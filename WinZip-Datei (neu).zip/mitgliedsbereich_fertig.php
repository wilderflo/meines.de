<!doctype html>
<html> 
    <head>
        <meta charset="utf-8"> 
        <title>eure Kontakt Daten</title> 
        <link href="style.css" rel="stylesheet">


    </head>
    <body> 
        <h1>an alle sonic freunde</h1>
        <img src=Sonic.jpg>
        <png src=sonic2.png>
            <ü>escape from the city</ü>
            <audio preload controls>
                <source src="SONIC_%20-%20Escape%20oo.mp3">
            </audio>   
            <ü>title music</ü>
            <br>

            <audio controls >
                <source src="Sonic.mp3">
            </audio> 

            <ing src="Sonic_the_Hedgehog.jpg"></ing>
            <br>
            <br>
            <br
                </body>
            <h1> an alle sonic freunde</h1>
            <ul class="site-nav-list">  
                <li><a href="index.html" class="sie-sind-hier">start</a></li>
                <li><a href="news.html">Info</a></li>
                <li><a href="konntakt.html">Kontakte</a></li>
                <li><a href="eurebeitr%C3%A4ge.php">eure beiträge</a></li>
                <li><a href="bestebeitr%C3%A4ge.php">eure besten beiträge</a></li>
                <li><a href="r%C3%BCckmeldung.html">Eure rückmeldungs Möglichkeit</a></li>
                <li><a href="MItgliedsbereich.html">Eurer Mitgliedsbereich</a></li>
            </ul>
            <form action="mitgliedsbereich_fertig.php" method="post">
            <fieldset>
                <legend>privarte Fragen die nur für echte sonic Freunde</legend>
                <o>
            <label>name des Autoren (also du!!!)</label>
                    <div class="row">
                        <div class="col-md-7">
            <input type="text" name="name" class="form-control" autofocus>
            </div>
                </div>
                    <div>
                <lable>Beitrag<span class="red"></span></lable>
          <div class="row">                
        <div class="col-md-11">
         <textarea rows="5" name="nachricht"  class="form-control"required></textarea>
              </div>
             </div>
        <o>
        <button type="submit" name="abschicken" class="btn"> Abschicken</button>
           </o>
                
                </fieldset>
        </form>
        <?php
 if(isset($_POST['abschicken']))
 {
   require("inc/db_connect.php");  
     
$name = $_POST['name'];
$nachricht = $_POST['nachricht']; 
     $sql = "INSERT INTO tbl_privartenachrichten(Name, Nachricht) VALUES(:name, :nachricht)";
     $stmt = $dbh->prepare($sql);
     $stmt->bindValue(':name', $name);
     $stmt->bindValue(':nachricht', $nachricht);
    
      
     
     $stmt->execute();   
  }    
?>
                <?php
        require("inc/db_connect.php");

        $sth = $dbh->prepare("SELECT * FROM tbl_privartenachrichten");
        $sth->execute();

        $ergebnisse = $sth->fetchAll();

        foreach($ergebnisse as $ergebnis) {
            echo"<div class='beitrag'><p class='name'>".$ergebnis['name']."</p>
            <p class='nachricht'>".$ergebnis['nachricht']."</p>";
            $stmnt = $dbh->prepare("SELECT * FROM tbl_ = ".$ergebnis['N_ID']);
            $stmnt->execute();

            $komentare = $stmnt->fetchAll();

            if($komentare) {
                foreach($komentare as $komentar) {
                    echo '<p>Name:'.$komentar['name'].'</p>';
                    echo '<p>Kommentar:'.$komentar['komentar'].'</p>';
                }
            }

            echo'<form action="eurebeiträge.php" method="post">
            <label>name</label>
                    <div class="row">
                        <div class="col-md-7">
            <input type="text" name="name" class="form-control" autofocus>
            </div>
                </div>

            <div>
                <lable>Kommentar</lable>
                <textarea rows="5" name="nachricht"  class="form-control"required></textarea>
                <input type="hidden" name="bertrags_id" value="'.$ergebnis['N_ID'].'">
            </div>
            <o>
                <button type="submit" name="abschicken" class="btn">Abschicken</button>
            </o>
        </form></div>';
            echo "<hr />";
        }

        ?>
        <a href="hilfe.html">hilfe???</a>
        <br>
    