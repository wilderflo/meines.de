<!doctype html>
<html> 
    <head>
        <meta charset="utf-8"> 
        <title>eure Kontakt Daten</title> 
        <link href="style.css" rel="stylesheet">


    </head>
    <body> 
        <h1>an alle sonic freunde</h1>
        <img src=Sonic.jpg>
        <png src=sonic2.png>
            <ü>escape from the city</ü>
            <audio preload controls>
                <source src="SONIC_%20-%20Escape%20oo.mp3">
            </audio>   
            <ü>title music</ü>
            <br>

            <audio controls >
                <source src="Sonic.mp3">
            </audio> 

            <ing src="Sonic_the_Hedgehog.jpg"></ing>
            <br>
            <br>
            <br
                </body>
            <h1> an alle sonic freunde</h1>
            <ul class="site-nav-list">  
                <li><a href="index.html" class="sie-sind-hier">start</a></li>
                <li><a href="news.html">Info</a></li>
                <li><a href="konntakt.html">Kontakte</a></li>
                <li><a href="eurebeitr%C3%A4ge.php">eure beiträge</a></li>
                <li><a href="bestebeitr%C3%A4ge.php">eure besten beiträge</a></li>
                <li><a href="r%C3%BCckmeldung.html">Eure rückmeldungs Möglichkeit</a></li>
                <li><a href="MItgliedsbereich.html">Eurer Mitgliedsbereich</a></li>
                <br>

                <?php
                require("inc/db_connect.php");

                $sth = $dbh->prepare("SELECT * FROM tbl_kontaktformular");
                $sth->execute();

                $ergebnisse = $sth->fetchAll();

                foreach($ergebnisse as $ergebnis) {
                    echo"<div class='beitrag'><p class='name'>".$ergebnis['Name']."</p><p class='nachricht'>".$ergebnis['Nachricht']."</p>
<p class='e-mail'>".$ergebnis['Email']."</p><p class='datum'>".$ergebnis['Datum']."</p></div>";
                   
                }

                ?>
               
                <footer class="site-footer">

                    <a href="#top">Nach oben</a>