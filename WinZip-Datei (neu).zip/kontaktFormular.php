<!doctype>
<html> 
   <head>
     <meta charset="utf-8"> 
      <title>Kontaktformular</title> 
       <link href="style.css" rel="stylesheet">
       
       <style>
           
           lable {
               display: block;
           }
           form div {
             margin-bottom:1em;   
           }
          
       </style>
</head>
<h1><img src=wasser_im_comic_style_0001.jpg></h1>
           <p>ich hoffe das diese arbeit ein guter start ist</p>
           <ul class="site-nav-list">  
               <li><a href="index.html" class="sie-sind-hier">start</a></li>
               <li><a href="news.html">Info</a></li>
              <li><a href="konntakt.html">Kontakte</a></li>
               <li><a href="eurebeitr%C3%A4ge.php">eure beiträge</a></li>
               <li><a href="bestebeitr%C3%A4ge.php">eure besten beiträge</a></li>
               <li><a href="r%C3%BCckmeldung.html">Eure rückmeldungs Möglichkeit</a></li>
               <li><a href="MItgliedsbereich.html">Eurer Mitgliedsbereich</a></li>
            </ul>
<title>kontacktformular</title>
</head>
    <body>
        <audio controls  >
   <source src="Sonic.mp3">
    </audio> 
          <address style="font-style: normal;">
            colin Brockschmidt <br>
          sven-hedin-str. 77 <br>
          26389 Wilhelmshaven <br>
          <br>
          tel:<a href="tel: +4944213007102">04421 3007102</a>a>
      </address>
        <br>
        <br>
        <br>
        <form action="kontaktFormular.php" method="post">
            <fieldset>
                <legend>Daten angeben</legend>
                <o>
            <label>name</label>
                    <div class="row">
                        <div class="col-md-7">
            <input type="text" name="name" class="form-control" autofocus>
            </div>
                </div>
             <label>e-mail<span class="red"></span></label>
                    <div class="row">
                        <div class="col-md-7">
            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                <lable>Nachricht<span class="red"></span></lable>
          <div class="row">                
        <div class="col-md-11">
         <textarea rows="5" name="nachricht"  class="form-control"required></textarea>
              </div>
             </div>
        <o>
        <button type="submit" name="abschicken" class="btn"> Abschicken</button>
           </o>
                </o>
                
                </fieldset>
        </form>
        

        <br>
    
    </body>
</html>
<?php
 if(isset($_POST['abschicken']))
 {
   require("inc/db_connect.php");  
     
$name = $_POST['name'];
$email = $_POST['email'];
$nachricht = $_POST['nachricht'];
$datum = date("Y-m-d H:i:s"); 
     $sql = "INSERT INTO tbl_kontaktformular(Name, Email, Nachricht, Datum) VALUES(:name, :email, :nachricht, :datum)";
     $stmt = $dbh->prepare($sql);
     $stmt->bindValue(':name', $name);
     $stmt->bindValue(':email', $email);
     $stmt->bindValue(':nachricht', $nachricht);
     $stmt->bindValue(':datum', $datum);
      
     
     $stmt->execute();   
  }    
?>