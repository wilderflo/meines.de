
<html> 
    <head>
        <meta charset="utf-8"> 
        <title>eure Beiträge</title> 
        <link href="style.css" rel="stylesheet">


    </head>
    <body> 
    
        <img src=Sonic.jpg><img src="sonic2.png" class="img-fluid" alt="Responsive image" width="212.5px" height="325px">
        <br>

        <br>
        <audio controls >
            <source src="Sonic.mp3">
        </audio> 


        
        <h1>an alle sonic freunde</h1>
        <ul class="site-nav-list">  
            <li><a href="index.html" class="sie-sind-hier">start</a></li>
            <li><a href="news.html">Info</a></li>
            <li><a href="konntakt.html">Kontakte</a></li>
            <li><a href="eurebeitr%C3%A4ge.php">eure beiträge</a></li>
            <li><a href="bestebeitr%C3%A4ge.php">eure besten beiträge</a></li><li>
            <li><a href="MItgliedsbereich.html">Eurer Mitgliedsbereich</a></li>
        </ul>
        <br />
        <br />
        <form class="bericht.php"  action="beitrag.php" method="post">
            <button type="submit">hier zum erstellen eines eigenen beitragen,</button></form>;
        <?php
        require("inc/db_connect.php");

        $sth = $dbh->prepare("SELECT * FROM tbl_beitrag");
        $sth->execute();

        $ergebnisse = $sth->fetchAll();

        foreach($ergebnisse as $ergebnis) {
            echo"<div class='beitrag'><p class='name'>".$ergebnis['Name']."</p>
            <p class='nachricht'>".$ergebnis['Nachricht']."</p>";
            $stmnt = $dbh->prepare("SELECT * FROM tbl_koments where bertrags_id = ".$ergebnis['N_ID']);
            $stmnt->execute();

            $komentare = $stmnt->fetchAll();

            if($komentare) {
                foreach($komentare as $komentar) {
                    echo '<p>Name:'.$komentar['name'].'</p>';
                    echo '<p>Kommentar:'.$komentar['komentar'].'</p>';
                }
            }

            echo'<form action="eurebeiträge.php" method="post">
            <label>name</label>
                    <div class="row">
                        <div class="col-md-7">
            <input type="text" name="name" class="form-control" autofocus>
            </div>
                </div>

            <div>
                <lable>Kommentar</lable>
                <textarea rows="5" name="nachricht"  class="form-control"required></textarea>
                <input type="hidden" name="bertrags_id" value="'.$ergebnis['N_ID'].'">
            </div>
            <o>
                <button type="submit" name="abschicken" class="btn">Abschicken</button>
            </o>
        </form></div>';
            echo "<hr />";
        }

        ?>


        <footer class="site-footer">

            <a href="#top">Nach oben</a> 
        </footer>
    </body>
</html>
<?php
if(isset($_POST['abschicken']))
{
    require("inc/db_connect.php");  
    $id = $_POST['bertrags_id'];    
    $name = $_POST['name'];
    $nachricht = $_POST['nachricht']; 
    $sql = "INSERT INTO tbl_koments(name, komentar, bertrags_id) VALUES(:name, :komentar, :bertrags_id)";
    $stmt = $dbh->prepare($sql);
    $stmt->bindValue(':name', $name);
    $stmt->bindValue(':komentar', $nachricht);
    $stmt->bindValue(':bertrags_id', $id);


    $stmt->execute();   
}    
?>