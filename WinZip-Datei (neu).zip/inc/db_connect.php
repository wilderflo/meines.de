<?php
$user = "KontakFormular";
$pass = "FJsl7RddQ5iPUAp4";
    
try
{
    $dbh=new PDO('mysql:host=localhost;dbname=webseite jade-hochschule;charset=utf8', $user, $pass);
}
catch (PDOEException $e)
{
    print "error: " . $e->getMessage() . "<br/>";
    die();    
}
?>