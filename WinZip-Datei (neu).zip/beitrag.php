<!doctype>
<html> 
   <head>
     <meta charset="utf-8"> 
      <title>Beiträge</title> 
       <link href="style.css" rel="stylesheet">
       
       <style>
           
           lable {
               display: block;
           }
           form div {
             margin-bottom:1em;   
           }
          
       </style>
</head>
<h1><img src=Sonic.jpg> </h1>
    <h3><ing src="Sonic_the_Hedgehog.jpg"></ing></h3>
           <p>an alle Sonic Freunde</p>
           <ul class="site-nav-list">  
               <li><a href="index.html" class="sie-sind-hier">start</a></li>
               <li><a href="news.html">Info</a></li>
              <li><a href="konntakt.html">Kontakte</a></li>
               <li><a href="eurebeitr%C3%A4ge.php">eure beiträge</a></li>
               <li><a href="bestebeitr%C3%A4ge.php">eure besten beiträge</a></li>
               <li><a href="r%C3%BCckmeldung.html">Eure rückmeldungs Möglichkeit</a></li>
               <li><a href="MItgliedsbereich.html">Eurer Mitgliedsbereich</a></li>
            </ul>
<title>Beitrag erstellen</title>
</head>
    <body>
        <audio controls  >
   <source src="Sonic.mp3">
    </audio> 
          
        <br>
        <br>
        <br>
        <form action="beitrag.php" method="post">
            <fieldset>
                <legend>hier Beitrag erstellen</legend>
                <o>
            <label>name des Autoren (also du!!!)</label>
                    <div class="row">
                        <div class="col-md-7">
            <input type="text" name="name" class="form-control" autofocus>
            </div>
                </div>
             <label>e-mail<span class="red"></span></label>
                    <div class="row">
                        <div class="col-md-7">
            <input type="email" name="email" class="form-control" required>
                        </div>
                    <div>
                <lable>Beitrag<span class="red"></span></lable>
          <div class="row">                
        <div class="col-md-11">
         <textarea rows="5" name="nachricht"  class="form-control"required></textarea>
              </div>
             </div>
        <o>
        <button type="submit" name="abschicken" class="btn"> Abschicken</button>
           </o>
                </o>
                
                </fieldset>
        </form>
        
        <a href="hilfe.html">hilfe???</a>
        <br>
    
    </body>
</html>
<?php
 if(isset($_POST['abschicken']))
 {
   require("inc/db_connect.php");  
     
$name = $_POST['name'];
$email = $_POST['email'];
$nachricht = $_POST['nachricht'];
$datum = date("Y-m-d H:i:s"); 
     $sql = "INSERT INTO tbl_beitrag(Name, Email, Nachricht, Datum) VALUES(:name, :email, :nachricht, :datum)";
     $stmt = $dbh->prepare($sql);
     $stmt->bindValue(':name', $name);
     $stmt->bindValue(':email', $email);
     $stmt->bindValue(':nachricht', $nachricht);
     $stmt->bindValue(':datum', $datum);
      
     
     $stmt->execute();   
  }    
?>
        <footer class="site-footer">
      
      <a href="#top">Nach oben</a>