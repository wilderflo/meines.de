var input = window.prompt("gieb hier das passwort ein", "ok");
if (input == "passwort") {
    window.location.href = "test2.html"
}