<!doctype html>
<html> 
   <head>
     <meta charset="utf-8"> 
      <title>Fertiges kontaktformular</title> 
       <link href="style.css" rel="stylesheet">
       

 </head>
<body> 
<ing src="Sonic_the_Hedgehog.jpg"></ing>
           <h1>an alle sonic freunde</h1>
           <ul class="site-nav-list">  
               <li><a href="index.html" class="sie-sind-hier">start</a></li>
               <li><a href="news.html">Info</a></li>
              <li><a href="konntakt.html">Kontakte</a></li>
    <li><a href="eurebeitr%C3%A4ge.php">Eure Beiträge</a></li>
        <li><a href="bestebeitr%C3%A4ge.php">Eure besten Beiträge</a></li>
        <li><a href="r%C3%BCckmeldung.html">Eure rückmeldungs Möglichkeit</a></li>
        <li><a href="MItgliedsbereich.html">Eurer Mitgliedsbereich</a></li>
            </ul>
        <br>
        <br>
    <h2>wenn sie das richtige passwort eingegeben haben,dann werden sie weitergeleitet,
    wenn nicht ist es das falsche passwort (!!!wichtig nur für VIP mitglieder. mehr infos im hilfe bereich</h2>
    <p>danke und LG</p>
               <script>var input = window.prompt("gieb hier das passwort ein", "ok");
if (input == "27042004") {
    window.location.href = "eurekontaktdten2.php"
}</script>
    </body