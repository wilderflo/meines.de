    

<html> 
   <head>
     <meta charset="utf-8"> 
      <title>Beste Beiträge</title> 
       <link href="style.css" rel="stylesheet">
       
       
 </head>
<body> 
    <br>
    <br>

<br>
<br>
<ing src="Sonic.jpg"></ing>
    <br>
     
    <br>
        <audio controls >
   <source src="Sonic.mp3">
    </audio> 


        <h1><img src=Sonic.jpg> </h1>
    <h3><ing src="Sonic_the_Hedgehog.jpg"></ing></h3>
           <h1>an alle sonic freunde</h1>
           <ul class="site-nav-list">  
               <li><a href="index.html" class="sie-sind-hier">start</a></li>
               <li><a href="news.html">Info</a></li>
              <li><a href="konntakt.html">Kontakte</a></li>
               <li><a href="eurebeitr%C3%A4ge.php">eure beiträge</a></li>
               <li><a href="bestebeitr%C3%A4ge.php">eure besten beiträge</a></li>
               <li><a href="r%C3%BCckmeldung.html">Eure rückmeldungs Möglichkeit</a></li>
               <li><a href="MItgliedsbereich.html">Eurer Mitgliedsbereich</a></li>
            </ul>
    <br />
<br>

<?php
    
require("inc/db_connect.php");

$sth = $dbh->prepare("SELECT * FROM tbl_beitrag where tbl_beitrag.besterbeitrag = 1");
$sth->execute();

$ergebnisse = $sth->fetchAll();

foreach($ergebnisse as $ergebnis) {
    echo"<div class='beitrag'><p class='name'>".$ergebnis['Name']."</p><p class='nachricht'>".$ergebnis['Nachricht']."</p></div>";
    echo "<hr />";
    
}

?>